www.machinelearning.ru/wiki/index.php?title=COIL-20

20 классов картинок 32х32 по 72 поворотам

Код, чтобы посмотреть любое изображение:

import pandas as pd
import matplotlib.pyplot as plt

X = pd.read_csv('data.csv').values

def show_image(i, X): 
    img = X[i].reshape(32, 32)
    plt.imshow(img, cmap='gray')
    plt.show()

show_image(3, X)